// EncrypOptionDlg.cpp : ʵ���ļ�
//
#include "resource.h"
#include "stdafx.h"
#include "me.h"
#include "meDlg.h"
#include "EncrypOptionDlg.h"
#include "DecrypOptionDlg.h"
#include <math.h>

// CEncrypOptionDlg �Ի���

IMPLEMENT_DYNAMIC(CEncrypOptionDlg, CDialog)

CEncrypOptionDlg::CEncrypOptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEncrypOptionDlg::IDD, pParent)
	, mDesKey(_T(""))
	, m3DesKey(_T(""))
	, mAesKey(_T(""))
{

}

CEncrypOptionDlg::~CEncrypOptionDlg()
{
}

void CEncrypOptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_DES_KEY, mDesKey);
	DDX_Text(pDX, IDC_EDIT_3DES_KEY, m3DesKey);
	DDX_Text(pDX, IDC_EDIT_AES_KEY, mAesKey);
}


BEGIN_MESSAGE_MAP(CEncrypOptionDlg, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_CHOSE_FINISH, &CEncrypOptionDlg::OnBnClickedButtonChoseFinish)
	ON_BN_CLICKED(IDC_BUTTON_CREATE_KEYS, &CEncrypOptionDlg::OnBnClickedButtonCreateKeys)
END_MESSAGE_MAP()
///////////////////////////////�ж�����//////////////////////////// 
int CEncrypOptionDlg::judge_num(long n) 
{ 
	long temp=0,i; 
	for(i=37;i<=sqrt((double)n);i+=2)
	{
		if (n%i == 0 ) return 0;
	}
	return 1; 
} 

// CEncrypOptionDlg ��Ϣ��������

void CEncrypOptionDlg::OnBnClickedButtonChoseFinish()
{
	CButton* pDesCheck = (CButton*)GetDlgItem(IDC_CHECK_DES);
	int pDesCheckState = pDesCheck->GetCheck();
	CButton* p3DesCheck = (CButton*)GetDlgItem(IDC_CHECK_3DES);
	int p3DesCheckState = p3DesCheck->GetCheck();
	p3DesCheckState = p3DesCheckState<<1;
	CButton* pAesCheck = (CButton*)GetDlgItem(IDC_CHECK_AES);
	int pAesCheckState = pAesCheck->GetCheck();
	pAesCheckState = pAesCheckState<<2;
	CButton* pSM3Check = (CButton*)GetDlgItem(IDC_CHECK_SM3);
	int pSM3CheckState = pSM3Check->GetCheck();
	pSM3CheckState = pSM3CheckState<<3;
	CButton* pRsaCheck = (CButton*)GetDlgItem(IDC_CHECK_RSA);
	int pRsaCheckState = pRsaCheck->GetCheck();
	pRsaCheckState = pRsaCheckState<<4;
	/*CButton* pMd5Check = (CButton*)GetDlgItem(IDC_CHECK_MD5);
	int pMd5CheckState = pMd5Check->GetCheck();
	pMd5CheckState = pMd5CheckState<<5;*/
	CheckState = pDesCheckState + p3DesCheckState + pAesCheckState + pSM3CheckState + pRsaCheckState;// + pMd5CheckState ;    
	CmeApp * mApp = (CmeApp*)AfxGetApp( );
	UpdateData(true);//��edit�е����ݴ�������
	mApp->mMingwendlg = CheckState;
	mApp->AfxDesKey = mDesKey;	//��DES��Կ��ֵ��һ��ȫ�ֱ����洢��
	mApp->Afx3DesKey = m3DesKey;	//��3DES��Կ��ֵ��һ��ȫ�ֱ����洢��
	mApp->AfxAesKey = mAesKey;
	EndDialog(0);  
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CEncrypOptionDlg::OnBnClickedButtonCreateKeys()
{
	bool k=0;//��ʶ�Ƿ��ҵ�����������
	int P,Q,n,m,e,d;//������
	do{
		do{
			srand( (unsigned)time( NULL ) );
			P = rand();
			do 
			{
				P++;
			} while (!(P%2 && P%3&& P%5  && P%7 && P%11 && P%13 && P%17 && P%19 && P%23 && P%27 && P%29 && P%31));
		}while(!judge_num(P));

		do{
			srand( (unsigned)time( NULL ) );  
			Q = rand();
			do 
			{
				Q++;
			} while (!(Q%2 && Q%3&& Q%5  && Q%7 && Q%11 && Q%13 && Q%17 && Q%19 && Q%23 && Q%27 && Q%29 && Q%31)||( Q == P));
		}while(!judge_num(Q));
		//����n,m,e,d
		n=P*Q;
		m=(P-1)*(Q-1);

		for(e=2;e<=m/2;e++)
		{

			for(d=sqrt((double)n);d>0;d--)
				if((e*d)%m==1) 
				{

					AfxMessageBox(__T("OK�ˣ�"));
					k =1;
					break;

				}
				if (k )
				{
					break;
				}
		}
	}while(!k);
	CmeApp * mApp = (CmeApp*)AfxGetApp( );
	mApp->RSA_d = d;
	mApp->RSA_n = n;
	mApp->RSA_e = e;
	CString str_d,str_n;
	str_d.Format("%i",d);
	str_n.Format("%i",n);
	SetDlgItemText(IDC_RsaEncry_d,str_d);
	SetDlgItemText(IDC_RsaEncry_n,str_n);

	// TODO: �ڴ����ӿؼ�֪ͨ�����������

}
