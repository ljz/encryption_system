//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by me.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ME_DIALOG                   102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_ENCRYP_CHOSE         129
#define IDD_DIALOG_DECRYP_CHOSE         130
#define IDD_RSA_KEY_DLG                 131
#define IDC_BUTTON_CHOSE_PLAIN_FILE     1000
#define IDC_EDIT_MINGWEN                1001
#define IDC_BUTTON_ENCRYP               1002
#define IDC_BUTTON_ENCRYP_OPTION        1003
#define IDC_BUTTON_DECRYP               1004
#define IDC_BUTTON_CHOSE_DNCRYP_ALOGRITHM 1005
#define IDC_CHECK_DES                   1005
#define IDC_BUTTON_CHOSE_CIPHER_FILE    1006
#define IDC_CHECK_3DES                  1006
#define IDC_EDIT_MIWEN                  1007
#define IDC_CHECK_AES                   1007
#define IDC_CHECK_RSA                   1008
#define IDC_CHECK_SM3                   1011
#define IDC_EDIT_3DES_KEY               1012
#define IDC_EDIT_AES_KEY                1013
#define IDC_BUTTON_CREATE_KEYS          1014
#define IDC_BUTTON_CHOSE_FINISH         1015
#define IDC_EDIT_AES_KEY2               1016
#define IDC_EDIT_DES_KEY                1017
#define IDC_EDIT_SM5_KEY                1018
#define IDC_EDIT_3DES_UNKEY             1020
#define IDC_EDIT_UNDES_KEY              1021
#define IDC_EDIT_AES_UNKEY              1022
#define IDC_PublicKey                   1023
#define IDC_PrivateKey                  1024
#define IDC_RSA_E                       1026
#define IDC_RSA_Decry_n                 1026
#define IDC_RSA_E2                      1028
#define IDC_RsaEncry_n                  1028
#define IDC_RSA_Decry_d                 1028
#define IDC_EDIT2                       1029
#define IDC_RsaEncry_d                  1029
#define IDC_EDIT_TIME                   1029
#define IDC_LIST                        1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
